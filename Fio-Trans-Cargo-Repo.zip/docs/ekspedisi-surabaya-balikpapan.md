# Ekspedisi Surabaya Balikpapan

Fio Trans Cargo melayani pengiriman barang dari Surabaya ke Balikpapan dengan tarif terjangkau dan estimasi pengiriman cepat.

## Layanan Unggulan

- Kirim barang besar dan alat berat
- Tracking pengiriman online
- Asuransi pengiriman
- Layanan jemput barang

## Hubungi Kami

📱 WhatsApp: [0822-6497-2075](https://wa.me/6282264972075)  
🌐 Website: [fiotrans.com](https://fiotrans.com)
